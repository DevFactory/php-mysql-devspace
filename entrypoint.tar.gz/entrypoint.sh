#!/bin/bash

chmod -R 775 /var/lib/mysql

/etc/init.d/mysql start
/etc/init.d/nginx start

tail -f /dev/null